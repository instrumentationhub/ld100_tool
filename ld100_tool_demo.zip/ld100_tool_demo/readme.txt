==============================================================================
| ld100_tool 5.33.483 deployment pack overview | February 04, 2022 | coreIPM |
==============================================================================

Unpack this archive to any folder on your WinXP..Win10 machine, then run 
Setup.exe and follow instructions on your screen.

==============================================================================

Recent updates:
1. minor bugs fixed
2. ld100_tool manuals updated

==============================================================================

The installation contains executable files, libraries, and documents required 
for ld100_tool to run and ld100 instrumentation hub demonstration. 

For public use.
==============================================================================
