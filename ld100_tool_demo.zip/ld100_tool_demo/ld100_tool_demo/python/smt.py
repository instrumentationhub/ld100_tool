# -----------------------------------------------------------------------------
# 10.02.2018 .. 31.07.2018                                              rev.32
# ld100 shared memory demo/test  (multi-BMC support, single BMC use: BMC #0)
#
# Notes:
#   This is a top-level file for importing/reloading from python's console 
#   If no ld100_tool running, still this demo should work while showing errors
#   For correct results the ld100_tool should be run before smt is run,
#       and should have the J12 ems22 sensor polling enabled.
#
# Valid commands entered at the python command prompt, examples:
# >>> smt.sc.dump()                         # dump all shared memory
# >>> smt.sc.version()                      # show shared memory version
# >>> smt.sensor_get(smt.j12_sensor, smt.j12_ems22) # read ems22
# -----------------------------------------------------------------------------

# open the ld100_shared memory;, instantiate the "sc" class (of sm-type).
from smlib import *


# -----------------------------------------------------------------------------
# Test 1.
def t1():
    print "1. We set32/get32 (value=0x3377AACC)",   # (no linefeed)
    sc.set32(j16_sensor, 0x3377AACC)                # action: write to j16_sensor_status UINT32
    if( sc.get32(j16_sensor) == 0x3377AACC):
        print "-- success"                          # ... trailer
    else:
        print "-- failed"  
         
# -----------------------------------------------------------------------------
# Test 2.
def t2():
    try:
        sensor_data = sc.sensor_get_any(0, j12_sensor)                                     # <----|
        print "   J12 sensor data:" , hex(sensor_data)
    except RuntimeError:
        print "   J12 ems22 bad data or time out."

# -----------------------------------------------------------------------------
# Test 3.
def t3():
    for i in range(3):
        sensor_data = sc.sensor_get(0, j12_sensor, j12_spi_sensor_type_encoder_ems22)      # <----|
        if(sensor_config_invalid >= sensor_data):
            print "  ", i, ". J12 ems22:" , hex(sensor_data)
        else:
            print "  ", i, " -- J12 ems22 misconfigured or timed out:" , hex(sensor_data)

# -----------------------------------------------------------------------------
# Test 4.
def t4():
    print "   J5, J6, J7  PWM settings:           0x{0:04x} 0x{1:04x} 0x{2:04x}".format( sc.read_poll_settings(0, j5_settings), \
      sc.read_poll_settings(0, j6_settings),  sc.read_poll_settings(0, j7_settings)  )
      
    print "   J8, J9, J10 i2c&tach poll settings: 0x{0:04x} 0x{1:04x} 0x{2:04x}".format( sc.read_poll_settings(0, j8_settings), \
      sc.read_poll_settings(0, j9_settings),  sc.read_poll_settings(0, j10_settings) )
      
    #print "J11,J12 poll, and J13,J14 baud settings: 0x{0:04x} 0x{1:04x} 0x{2:04x} 0x{3:04x}".format( sc.read_poll_settings(0, j11_settings), \
    #      sc.read_poll_settings(0, j12_settings), sc.read_poll_settings(0, j13_settings), sc.read_poll_settings(0, j14_settings) )
    #      
    print "   J11,J12 spi poll settings:          0x{0:04x} 0x{1:04x}".format(sc.read_poll_settings(0, j11_settings), \
      sc.read_poll_settings(0, j12_settings))
      
    print "   J18,J19,J20 gpio poll settings:     0x{0:04x} 0x{1:04x} 0x{2:04x}".format( sc.read_poll_settings(0, j18_settings), \
      sc.read_poll_settings(0, j19_settings), sc.read_poll_settings(0, j20_settings) )


# -----------------------------------------------------------------------------
# Test 5.
def t5():
    stat = sc.pwm_set(j5_sensor, 20)                                            # <----| set all to 20%
    stat = sc.pwm_set(j6_sensor, 25, pwm_pinmask_pin2)                          # <----| set pin2 to 25%
    stat = sc.pwm_set(j7_sensor, 33, pwm_pinmask_pin3, 90)                      # <----| set pin3 to 33%, and period=90
    stat = sc.gpio_set( 0, 1 )                                                  # <----| set BMC0.J18 pin 1 = 1
    stat = sc.gpio_set( 0, 2, 0)                                                # <----| set J18.2 = 0
    stat = sc.gpio_set( 0, 8 )                                                  # <----| set J19.3 = 1
    stat = sc.gpio_set( 0, 9, 0)                                                # <----| set J19.4 = 0
    stat = sc.gpio_set( 0, 16 )                                                 # <----| set J20.5 = 1 (High)
    stat = sc.gpio_set( 0, 17, 0)                                               # <----| set BMC0.J20.6 = 0 (Low)

# -----------------------------------------------------------------------------
# Test 6.
def t6():
    print "   J18,J19,J20 GPIO pins: 0x{0:05x} dirs: 0x{1:05x}".format( \
        sc.get32(gpio_pins_offset), sc.get32(gpio_dirs_offset) )


# -----------------------------------------------------------------------------
# Testing methods of the sm class.
#
sc.version();                                   # check integrity, print version info.
'''
 1. shared_mem writing demo/test.
    Try writing anything anywhere in the shared mem, and see if it works.
'''
t1()

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# 2. sensor reading demo.
# Try reading the sensor (ems22 rotary encoder)
#
print "2. Try 'any' sensor reading method .."
t2()

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# 3. The timed-out reading of the ems22 sensor : loop of 3 trials
#
print "3. Reading/printing J12-connected sensor EMS22,   3 times"
t3()

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# 4. More sharem_mem access samples (verbose)
#
print "4. Polling intervals, per connector. Note: 0x2000 bit, if set, means 'Polling disabled'"
t4()

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# 5. More sharem_mem access samples (silent: no diagnostics, waiting for status)
#
stat = sc.read_version()                                                        # <----| silently read version
# sensor data:
# j15_adc_sensor_type_raw_data[]     j10_tach_sensor_type_raw_data[]    j11_spi_sensor_type_encoder_ems22   j12_spi_sensor_type_encoder_ems22
# j11_spi_sensor_type_loadcell_hx711 j11_spi_sensor_type_max3155k       j11_spi_sensor_type_max3155i        j11_spi_sensor_type_pt100
# j11_12_spi_sensor_type_addon0      j11_12_spi_sensor_type_addon1      j12_spi_sensor_type_max3155k        j12_spi_sensor_type_max3155i
# j12_spi_sensor_type_loadcell_hx711 j12_spi_sensor_type_pt100          j89_i2c_sensor_type_mlx90_thermo    j89_i2c_sensor_type_bme280
# j89_i2c_sensor_type_lsm9_mag       j8_i2c_sensor_type_lsm9_accel      j8_i2c_sensor_type_lsm9_gyro        j89_i2c_sensor_type_vl6180
# j89_i2c_sensor_type_addon0         j89_i2c_sensor_type_addon1

print "5a.Silent reading J8, J9 I2C sensors",
sensor_data = sc.sensor_get(0, j8_sensor, j89_i2c_sensor_type_lsm9_mag)            # <----|
sensor_data = sc.sensor_get(0, j9_sensor, j89_i2c_sensor_type_lsm9_mag)            # <----|
print ".",      # progress indicator
sensor_data = sc.sensor_get(0, j8_sensor, j89_i2c_sensor_type_mlx90_thermo)        # <----|
sensor_data = sc.sensor_get(0, j9_sensor, j89_i2c_sensor_type_mlx90_thermo)        # <----|
print ".",      # progress indicator
sensor_data = sc.sensor_get(0, j8_sensor, j89_i2c_sensor_type_bme280)              # <----|
sensor_data = sc.sensor_get(0, j9_sensor, j89_i2c_sensor_type_bme280)              # <----|
print ".",      # progress indicator
sensor_data = sc.sensor_get(0, j8_sensor, j8_i2c_sensor_type_lsm9_accel)           # <----|
sensor_data = sc.sensor_get(0, j9_sensor, j8_i2c_sensor_type_lsm9_accel)           # <----|
print ".",      # progress indicator
sensor_data = sc.sensor_get(0, j8_sensor, j8_i2c_sensor_type_lsm9_gyro)            # <----|
sensor_data = sc.sensor_get(0, j9_sensor, j8_i2c_sensor_type_lsm9_gyro)            # <----|
print ".",      # progress indicator
sensor_data = sc.sensor_get(0, j8_sensor, j89_i2c_sensor_type_vl6180)              # <----|
sensor_data = sc.sensor_get(0, j9_sensor, j89_i2c_sensor_type_vl6180)              # <----|
print ".",      # progress indicator
sensor_data = sc.sensor_get(0, j8_sensor, j89_i2c_sensor_type_addon0)              # <----|
sensor_data = sc.sensor_get(0, j9_sensor, j89_i2c_sensor_type_addon1)              # <----|
print "."       # progress terminator

print "5b.Silent reading J11, J12 SPI sensors",
sensor_data = sc.sensor_get(0, j11_sensor, j11_spi_sensor_type_encoder_ems22)      # <----|
sensor_data = sc.sensor_get(0, j12_sensor, j12_spi_sensor_type_encoder_ems22)      # <----|
print ".",      # progress indicator
sensor_data = sc.sensor_get(0, j11_sensor, j11_12_spi_sensor_type_loadcell_hx711)  # <----|
sensor_data = sc.sensor_get(0, j12_sensor, j11_12_spi_sensor_type_loadcell_hx711)  # <----|
print ".",      # progress indicator
sensor_data = sc.sensor_get(0, j11_sensor, j11_spi_sensor_type_max3155k)           # <----|
sensor_data = sc.sensor_get(0, j12_sensor, j12_spi_sensor_type_max3155k)           # <----|
print ".",      # progress indicator
sensor_data = sc.sensor_get(0, j11_sensor, j11_spi_sensor_type_max3155i)           # <----|
sensor_data = sc.sensor_get(0, j12_sensor, j12_spi_sensor_type_max3155i)           # <----|
print ".",      # progress indicator
sensor_data = sc.sensor_get(0, j11_sensor, j11_spi_sensor_type_pt100)              # <----|
sensor_data = sc.sensor_get(0, j12_sensor, j12_spi_sensor_type_pt100)              # <----|
print ".",      # progress indicator
sensor_data = sc.sensor_get(0, j11_sensor, j11_12_spi_sensor_type_addon0)          # <----|
sensor_data = sc.sensor_get(0, j12_sensor, j11_12_spi_sensor_type_addon1)          # <----|
print "."       # progress terminator

print "5c.Silent reading J10 (tach), J15 (ADC), and J18..J20 (GPIO) sensors."
sensor_data = sc.sensor_get(0, j10_sensor, j10_tach_sensor_type_raw_data)              # <----|
sensor_data = sc.sensor_get(0, j15_sensor, j15_adc_sensor_type_raw_data)               # <----|
sensor_data = sc.sensor_get(0, j20_sensor,j181920_gpio_sensor_type_ds18b20_temperature)# <----|

print "5d.Silent setting PWM modes, and GPIO pins' state"
t5()

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
#
print "6. Print GPIO states & directions: Bit0=J18.1 - Bit17=J20.6; 6 pins/connector, 18 total."
t6()

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
#
'''
    Dump the whole shared memory to see the result.
'''
sc.dump()                                                                       # show full resulting shared_mem

#        
# end of smt.py
# -----------------------------------------------------------------------------
