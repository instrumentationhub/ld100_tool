#------------------------------------------------------------------------------------
# coreIPM                                                  last revised: jul 30, 2018
# ld100 shared memory accessing module (multi-BMC)         doc.rev: 33
#
import mmap
from LD100_INTF import *               #  ld100_intf.h converted to Python using h2py
from time import sleep

#------------------------------------------------------------------------------------
#
# shared memory data constants:                     (see also ld100_intf.h)
#
sm_fixed_pattern_offset = shared_mem_fixed_pattern_offset
sm_fixed_pattern        = 0x100000000 - abs(shared_mem_fixed_pattern) # h2py issue
# sm class status codes:
sensor_data_invalid     = 0xFFFFFFFF
sensor_config_invalid   = 0xFFFFFFFE
pwm_pinmask_both        = 0x03          # ld100 connectors J5, J6, J7: pin #2  and #3
pwm_pinmask_pin2        = 0x01          # ld100 connectors J5, J6, J7: pin #2
pwm_pinmask_pin3        = 0x02          # ld100 connectors J5, J6, J7: pin #3

#------------------------------------------------------------------------------------
#
class sm:

    def __init__(self):
        self.sm = mmap.mmap(0, shared_mem_size_bytes, SHARED_MEM_NAME)
        if __name__ == '__main__': # When run for testing only
            self.dump()

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# Shared memory access. Primary methods.
#
    ''' 
    get32 : compose 32-bit unsigned integer value, 
            from 4 shared_mem chars, at the offset=idx 
    '''
    def get32(self, idx):
        val  = ord(self.sm[idx+3]);   val *= 256
        val += ord(self.sm[idx+2]);   val *= 256
        val += ord(self.sm[idx+1]);   val *= 256
        val += ord(self.sm[idx+0])
        return val
     
    '''   
    set32 : set 4 chars of the list, to the 32-bit unsigned integer specified
    '''
    def set32(self, idx, value):
        # if value < 0 or value > MAX_INT or idx < 0 or idx > shared_mem_size_bytes
        #   then generate exception (todo)
        self.sm[idx]   = chr(value       & 0xFF)
        self.sm[idx+1] = chr(value >>  8 & 0xFF)
        self.sm[idx+2] = chr(value >> 16 & 0xFF)
        self.sm[idx+3] = chr(value >> 24 & 0xFF)
        
            
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# secondary class methods. silent, non-waiting
#

    '''
    read_version():
      Return: 32-bit shared_mem version (4 bytes packed)
      Read the shared memory service version. See also "version()" method.
    '''
    def read_version(self):
        return self.get32(shared_mem_firmware_version_offset)
        
    # Return: connector poll interval (Bit13 = 0x2000 = "polling is disabled")
    def read_poll_settings(self, bmc, connector_id):
        return self.get32(connector_id + bmc*bmc_shared_data_size + bmc_data_offset)
        
    #Return: (J18.2..J18.6)=Bit0..Bit5; (J19.2..J19.6)=Bit6..Bit11; (J20.2..J20.6)=Bit12..Bit17; 
    def gpio_get_direction_settings(self, bmc):
        return self.get32(shared_mem_j18_sensor_data_offset + bmc*bmc_shared_data_size + bmc_data_offset)

    # if value = 0 then : "set this pin to 0" = "clear pin"
    def gpio_set(self, bmc, pin_number, value = 1):
        for delay in [0.1, 0.3, 0.6, 1.0] :
            stat = sc.get32(j20_sensor + bmc*bmc_shared_data_size + bmc_data_offset)             # check "available"
            if( stat == sensor_type_none ): break
            sleep(delay)     
        
       # print "Debug. pin={0:05x} v={1:02X} {2:05X} stat={3:05x}".format( pin_number, value, \
       #     (pin_number & 0x1F)|((value & 1)<< 7 ), stat )
        
        
        self.set32(shared_mem_j20_sensor_data_offset + bmc*bmc_shared_data_size + bmc_data_offset, (pin_number & 0x1F)|((value & 1)<< 7 ))
        self.set32(j20_sensor + bmc*bmc_shared_data_size + bmc_data_offset, j181920_gpio_sensor_type_raw_data)
        
        
    # defaults: pin_number = 0 = "all", period = 100 ticks
    def pwm_set(self, connector_id, duty, pin_number = pwm_pinmask_both, period = 100):
    
        if self.get32(connector_id) != j6_pwm_sensor_type_none: return
        
        self.set32(connector_id + shared_memory_sensor_stat_to_data_offset, (period << 24) + (pin_number << 16) + duty)
        self.set32(connector_id, j6_pwm_sensor_type_none)   
        
            
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# secondary class methods. (semi-)silent, waiting. 
#

    #
    # Sensor reading (helper) procedure. Silent.
    # Single try; sensor polling should be set up from the ld100_tool
    #
    def sensor_get_any(self, bmc, sensor_base):
        stat = sc.get32(sensor_base + shared_memory_sensor_stat_to_data_offset)
        if( stat == sensor_type_none ):
            sleep(1)
            stat = sc.get32(sensor_base + shared_memory_sensor_stat_to_data_offset)
            if( stat == sensor_type_none ):
                    raise RuntimeError # return sensor_data_invalid
        d = sc.get32(sensor_base + shared_memory_sensor_stat_to_data_offset + shared_memory_sensor_stat_to_data_offset)
        sc.set32(sensor_base + shared_memory_sensor_stat_to_data_offset, sensor_type_none) # invalidate status
        return d
    
    #
    # Sensor reading procedure.
    #
    def sensor_get(self, bmc, sensor_base, sensor_type):
        for delay in [0.2, 0.4, 0.8, 1.0] :
            # bmc_shared_data is a window uccupied by all of the single bmc data
            stat = sc.get32(sensor_base + bmc*bmc_shared_data_size + bmc_data_offset)
            if( stat == sensor_type_none ): sleep(delay)
            else:                           break
        else:
            if( stat == sensor_type_none ): return sensor_data_invalid
        
        if ( stat != sensor_type ):         # not our sensor responded on this connector
            return sensor_config_invalid    # raise RuntimeError 
            
        # read the data, and reset status   
        d = sc.get32(sensor_base + shared_memory_sensor_stat_to_data_offset)
        sc.set32(sensor_base, sensor_type_none) # invalidate status
        return d

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# secondary class methods. printing.
#

    # Print the shared memory service version.
    def version(self):
        if self.get32(shared_mem_fixed_pattern_offset) == sm_fixed_pattern: # 0xa5a5a5a5:
            print "smLib33> LD100_tool shared memory ver: {0}.{1} -- ok. MAX_BMC={2}".format( \
                ord(self.sm[shared_mem_firmware_version_offset+2]), \
                ord(self.sm[shared_mem_firmware_version_offset]) + ord(self.sm[shared_mem_firmware_version_offset+1]) *256, \
                ord(self.sm[shared_mem_bmc_max_offset])) 
        else:
            print "LD100_tool shared memory -- bad signature: {0}> 0x{1:08x}    (must be 0x{2:08x})".format(shared_mem_fixed_pattern_offset, \
                self.get32(shared_mem_fixed_pattern_offset), sm_fixed_pattern) 
                # self.get32(shared_mem_fixed_pattern_offset), shared_mem_fixed_pattern) 
            if self.sm[shared_mem_firmware_version_offset+2] != SupportedServiceRevisionNumberMinor_exact:
                print "LD100_tool -- bad version: {0} (must be {1})".format(ord(self.sm[shared_mem_firmware_version_offset+2]), \
                  SupportedServiceRevisionNumberMinor_exact)

    # print all the shared mem contents. 
    def dump(self):
        if self.sm:
            self.version()
    #       for i in [0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448, 480, 512]:
            for i in [0, 32, 64, 96, 128, 160, 192]:
                print self.sm[i:i+8].encode("hex"),     self.sm[i+8:i+16].encode("hex"), \
                      self.sm[i+16:i+24].encode("hex"), self.sm[i+24:i+32].encode("hex")
            else:
                print self.sm[224:232].encode("hex"), self.sm[2304:shared_mem_size_bytes].encode("hex")
        else :
            print("ld100_shared_mem opening error")
      

#------------------------------------------------------------------------------------

sc = sm()               # an instance of the "shared_mem class"

#
#
# print'-----------------------  end of module sm.py  -------------------------------'
